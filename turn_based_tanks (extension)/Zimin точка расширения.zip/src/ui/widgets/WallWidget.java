package ui.widgets;

import model.objects.Wall;
import ui.ImageUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class WallWidget extends CellItemWidget {

    private final Wall _wall;

    public WallWidget(Wall wall) {
        _wall = wall;
        setPreferredSize(new Dimension(60, 60));
    }

    @Override
    protected BufferedImage getImage() {
        BufferedImage image = null;
        try {
            image = ImageIO.read(getWallImageFile());
            image = ImageUtils.resizeImage(image, 60, 60);
            //image = batteryImageWithChargeText(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return image;
    }

    @Override
    public CellWidget.Layer getLayer() {
        return CellWidget.Layer.TOP;
    }

    private File getWallImageFile() {
        return new File("images/wall.png");
    }

//    private BufferedImage batteryImageWithChargeText(BufferedImage wallImage) {
//        BufferedImage img = new BufferedImage(wallImage.getWidth(), 60, BufferedImage.TYPE_INT_ARGB);
//        Graphics g = img.getGraphics();
//        g.drawImage(wallImage, 0, 0, null);
//        return img;
//    }

    @Override
    protected Dimension getDimension() {
        return new Dimension(60,60);
    }
}
