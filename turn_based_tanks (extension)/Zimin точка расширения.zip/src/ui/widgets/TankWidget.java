package ui.widgets;

import event.*;
import model.Direction;
import model.objects.Tank;
import ui.ImageUtils;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static ui.ImageUtils.rotateImageClockwise;

public class TankWidget extends CellItemWidget {

    private final Tank _tank;

    public TankWidget(Tank tank) {
        _tank = tank;
        setPreferredSize(new Dimension(60, 60));
        addKeyListener(new TankController());

        setFocusable(true);
        requestFocus();
    }

    @Override
    protected BufferedImage getImage() {
        BufferedImage image = null;
        try {
            image = ImageIO.read(getTankImageFile());
            image = ImageUtils.resizeImage(image, 60, 60);

            if(_tank.turretDirection() == Direction.EAST) {
                image = rotateImageClockwise(image, 90);
            }
            else if(_tank.turretDirection() == Direction.SOUTH) {
                image = rotateImageClockwise(image, 180);
            }
            else if(_tank.turretDirection() == Direction.WEST) {
                image = rotateImageClockwise(image, 270);
            }
            //image = batteryImageWithChargeText(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return image;
    }

    private File getTankImageFile() {
        File file = null;

        if(_tank.team() == 1) {
            file = new File("images/tankY.png");
        }
        else if(_tank.team() == 2) {
            file = new File("images/tankG.png");
        }

        return file;
    }

    @Override
    public CellWidget.Layer getLayer() {
        return CellWidget.Layer.TOP;
    }

    @Override
    protected Dimension getDimension() {
        return new Dimension(60, 60);
    }

    private class TankController implements ObstacleListener, TankActionListener, KeyListener {

        @Override
        public void objectTakenDamage(DamageEvent event) {

        }

        @Override
        public void objectMoved(MovingEvent event) {

        }

        @Override
        public void objectDied(DieEvent event) {

        }

        @Override
        public void tankShot(TankActionEvent event) {

        }

        @Override
        public void bulletFlewOut(BulletEvent event) {

        }

        @Override
        public void tankSkippedGameTurn(TankActionEvent event) {

        }

        @Override
        public void turretTurned(TankActionEvent event) {

        }

        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();

            turnTurretAction(keyCode);
            moveAction(keyCode);

            //moveAction(keyCode);
//            changeBatteryAction(keyCode);
//            skipStepAction(keyCode);

            repaint();
        }

        @Override
        public void keyReleased(KeyEvent e) {

        }

        private void turnTurretAction(int keyCode) {
            if(keyCode == KeyEvent.VK_W) {
                _tank.turnTurret(Direction.NORTH);
            }
            else if(keyCode == KeyEvent.VK_D) {
                _tank.turnTurret(Direction.EAST);
            }
            else if(keyCode == KeyEvent.VK_S) {
                _tank.turnTurret(Direction.SOUTH);
            }
            else if(keyCode == KeyEvent.VK_A) {
                _tank.turnTurret(Direction.WEST);
            }
        }

        private void moveAction(int keyCode) {
            if(keyCode == KeyEvent.VK_UP) {
                _tank.move(Direction.NORTH);
            }
            else if(keyCode == KeyEvent.VK_RIGHT) {
                _tank.move(Direction.EAST);
            }
            else if(keyCode == KeyEvent.VK_DOWN) {
                _tank.move(Direction.SOUTH);
            }
            else if(keyCode == KeyEvent.VK_LEFT) {
                _tank.move(Direction.WEST);
            }
        }
    }
}
