package ui.widgets;

import ui.ImageUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CellWidget extends JPanel {

    private static final int CELL_SIZE = 60;

    public enum Layer {
        TOP,
        BOTTOM
    }
    private Map<Layer, CellItemWidget> _items = new HashMap();

    public CellWidget() {

        setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        setBackground(ImageUtils.BACKGROUND_COLOR);
        setPreferredSize(new Dimension(CELL_SIZE, CELL_SIZE));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        //g.drawRect(0,0,CELL_SIZE,CELL_SIZE);
        g.drawImage(getImage(), 0, 0, null);
    }

    protected BufferedImage getImage() {
        BufferedImage image = null;
        try {
            image = ImageIO.read(new File("images/cell.png"));
            image = ImageUtils.resizeImage(image, 60, 60);
            //image = batteryImageWithChargeText(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return image;
    }

    public void addItem(CellItemWidget item) {
        if(_items.size() > 2) throw new IllegalArgumentException();
        int index = -1;

        if (_items.containsKey(Layer.TOP)) {
            index = 0;
        }

        _items.put(item.getLayer(), item);
        add(item, index);
    }
}
