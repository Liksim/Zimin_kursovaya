package ui.widgets;

import model.Cell;
import model.Field;
import ui.WidgetFactory;

import javax.swing.*;
import java.awt.*;

public class FieldWidget extends JPanel {

    private final Field _field;
    private final WidgetFactory _widgetFactory;

    public FieldWidget(Field field, WidgetFactory widgetFactory) {
        _field = field;
        _widgetFactory = widgetFactory;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        fillField();
        //subscribeOnRobots();
        //field.addFieldlActionListener(new FieldController());
    }

    private void fillField() {
        for (int i = 0; i < _field.height(); ++i) {
            JPanel row = createRow(i);
            add(row);
        }
    }

    private JPanel createRow(int rowIndex) {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));

        for(int i = 0; i < _field.width(); ++i) {
            Cell cell = _field.cells()[rowIndex][i];
            CellWidget cellWidget = _widgetFactory.create(cell);
            row.add(cellWidget);
        }
        return row;
    }
}
