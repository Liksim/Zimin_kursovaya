package ui;

import model.Cell;
import model.objects.*;
import model.objects.Obstacle;
import ui.widgets.*;

import java.util.HashMap;
import java.util.Map;

public class WidgetFactory {

    private final Map<Cell, CellWidget> _cells = new HashMap<>();
    private final Map<Wall, WallWidget> _walls = new HashMap<>();
    private final Map<Water, WaterWidget> _water = new HashMap<>();
    private final Map<Headquarters, HeadquartersWidget> _headquarters = new HashMap<>();
    private final Map<Tank, TankWidget> _tanks = new HashMap<>();

    public CellWidget create(Cell cell) {
        if(_cells.containsKey(cell)) return _cells.get(cell);

        CellWidget cellWidget = new CellWidget();

        for(Obstacle obstacle : cell.obstacles()) {
            if (obstacle instanceof Wall) {
                WallWidget wallWidget = create((Wall) obstacle);
                cellWidget.addItem(wallWidget);
            } else if (obstacle instanceof Headquarters) {
                HeadquartersWidget headquartersWidget = create((Headquarters) obstacle);
                cellWidget.addItem(headquartersWidget);
            } else if (obstacle instanceof Tank) {
                TankWidget tankWidget = create((Tank) obstacle);
                cellWidget.addItem(tankWidget);
            } else if (obstacle instanceof Water) {
                WaterWidget waterWidget = create((Water) obstacle);
                cellWidget.addItem(waterWidget);
            }
        }

        if(cell.obstacles().size() == 0) {
            cellWidget.addItem(new ImageOfCell());
        }

        _cells.put(cell, cellWidget);
        return cellWidget;
    }

    public CellWidget getWidget(Cell cell) {
        return _cells.get(cell);
    }

    public WallWidget create(Wall wall) {
        if(_walls.containsKey(wall)) return _walls.get(wall);

        WallWidget item = new WallWidget(wall);
        _walls.put(wall, item);
        return item;
    }

    public WallWidget getWidget(Wall wall) {
        return _walls.get(wall);
    }

    public void remove(Wall wall) {
        _walls.remove(wall);
    }

    public WaterWidget create(Water water) {
        if(_water.containsKey(water)) return _water.get(water);

        WaterWidget item = new WaterWidget(water);
        _water.put(water, item);
        return item;
    }

    public WaterWidget getWidget(Water water) {
        return _water.get(water);
    }

    public HeadquartersWidget create(Headquarters headquarters) {
        if(_headquarters.containsKey(headquarters)) return _headquarters.get(headquarters);

        HeadquartersWidget item = new HeadquartersWidget(headquarters);
        _headquarters.put(headquarters, item);
        return item;
    }

    public HeadquartersWidget getWidget(Headquarters headquarters) {
        return _headquarters.get(headquarters);
    }

    public void remove(Headquarters headquarters) {
        _headquarters.remove(headquarters);
    }

    public TankWidget create(Tank tank) {
        if(_tanks.containsKey(tank)) return _tanks.get(tank);

        TankWidget item = new TankWidget(tank);
        _tanks.put(tank, item);
        return item;
    }

    public TankWidget getWidget(Tank tank) {
        return _tanks.get(tank);
    }

    public void remove(Tank tank) {
        _tanks.remove(tank);
    }
}
