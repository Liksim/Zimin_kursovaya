package event;

import java.util.EventListener;

public interface ObstacleListener extends EventListener {
    void objectDied(DieEvent event);
    void objectTakenDamage(DamageEvent event);
}
