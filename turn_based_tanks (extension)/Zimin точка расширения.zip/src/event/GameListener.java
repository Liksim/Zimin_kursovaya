package event;

import java.util.EventListener;

public interface GameListener extends EventListener {

    void turnPassed(GameEvent event);
    void winnerDetermined(GameEvent event);
}
