package model.objects;

import model.Direction;

public interface Moving {
    boolean move(Direction direction);
}
