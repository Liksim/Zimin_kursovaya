package model.objects;

public class Water extends Obstacle {
    @Override
    public boolean canBeInCellWith(Moving movingObstacle) {
        return true;
    }

    @Override
    public void takeDamage(int damage, int team) {

    }
}
