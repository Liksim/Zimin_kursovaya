package model.objects;

import event.*;
import model.Cell;
import model.Direction;

import java.util.ArrayList;

public class Bullet extends Obstacle implements Moving {
    private int _damage;

    public Bullet(int team, int damage) {
        setTeam(team);
        setDamage(damage);
    }

    @Override
    public boolean canBeInCellWith(Moving movingObstacle) {
        return false;
    }

    @Override
    public boolean move(Direction direction) {
        Cell neighborCell = _cell.neighborInDirection(direction);

            if(neighborCell != null) {  // Если есть соседняя ячейка

                ArrayList<Obstacle> obstacles = neighborCell.obstacles();
                boolean canMove = true;
                ArrayList<Obstacle> damageableObstacles = new ArrayList<>();

                for(Obstacle obstacle : obstacles) {
                    if(!obstacle.canBeInCellWith(this)) {   // Если препятствие может находиться в одной ячейке со снарядом
                        canMove = false;
                        damageableObstacles.add(obstacle);
                    }
                }

                if(canMove) {
                    Cell fromCell = _cell;

                    if(_cell.extractObstacle(this)) {
                        neighborCell.setObstacle(this);
                        fireBulletMoved(fromCell, neighborCell);
                        move(direction);
                        return true;
                    }
                    else {
                        throw new RuntimeException("В ячейке уже нет снаряда!");
                    }
                }

                for(Obstacle damageableObstacle : damageableObstacles) {
                    damageableObstacle.takeDamage(_damage, _team);
                }
            }

        die();
        return false;
    }

    public int damage(){
        return _damage;
    }

    public void setDamage(int damage) {
        _damage = damage;
    }

    //---------------События---------------
    private ArrayList<MovingListener> _movingListeners = new ArrayList<>();

    public void addMovingListener(MovingListener listener) {
        _movingListeners.add(listener);
    }

    public void removeMovingListener(MovingListener listener) {
        _movingListeners.remove(listener);
    }

    private void fireBulletMoved(Cell fromCell, Cell toCell) {
        for(MovingListener listener : _movingListeners) {
            MovingEvent event = new MovingEvent(this);
            event.setFromCell(fromCell);
            event.setToCell(toCell);
            event.setObject(this);
            listener.objectMoved(event);
        }
    }
}
