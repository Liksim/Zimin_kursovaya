import model.Game;
import ui.WidgetFactory;
import ui.widgets.FieldWidget;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(GamePanel::new);
    }

    static class GamePanel extends JFrame {

        private Game _game;
        private WidgetFactory _widgetFactory;
        public GamePanel() throws HeadlessException {
            setVisible(true);

            _widgetFactory = new WidgetFactory();
            _game = new Game();
            _game.startGame();

            JPanel content = (JPanel) this.getContentPane();
            content.add(new FieldWidget(_game.field(), _widgetFactory));

            pack();
            setResizable(false);
            setDefaultCloseOperation(EXIT_ON_CLOSE);
        }
    }
}