package model;

import model.objects.Tank;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class FieldTest {

    @Test
    void createTest() {
        Cell[][] cells = new Cell[0][0];
        ArrayList<Tank> tanks = new ArrayList<>();
        Field field = new Field(10, 10, cells, tanks);
        assertNotNull(field);
        assertSame(field.cells(), cells);
        assertSame(field.tanks(), tanks);
    }

//    @Test
//    void createTest1() {
//        Cell cell1 = new Cell("1");
//        Cell cell2 = new Cell("2");
//        ArrayList<Cell> cells = new ArrayList<>();
//        cells.add(cell1);
//        ArrayList<Tank> tanks = new ArrayList<>();
//        Field field = new Field(cells, tanks);
//
//        cells.clear();
//        cells.add(cell2);
//
//        assertEquals(cell1._test, field.cells().get(0)._test);
//    }

    private boolean assertArrayEquals(ArrayList<Tank> tanks, ArrayList<Tank> expTanks) {
        if (tanks == null && expTanks == null) {
            return true;
        }
        else if(tanks == null || expTanks == null) {
            return false;
        }
        else if(tanks.size() != expTanks.size()) {
            return false;
        }

        for (int i = 0; i < tanks.size(); i++){
            if(tankEquals(tanks.get(i), expTanks.get(i))){
                return false;
            }
        }
        return true;
    }

    private boolean tankEquals(Tank first, Tank second){
        return false;
    }
}